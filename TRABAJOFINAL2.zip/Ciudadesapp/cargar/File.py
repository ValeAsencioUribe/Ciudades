# Carga las ciudades que estan en el archivo paises.csv
# -*- coding: utf-8 -*-
import csv
 
FileName = "/home/vale/Escritorio/paises.cvs"
File = open(FileName, "rb")
reader = csv.reader(File)
  
#Arreglo para almacenar las ciudades
detalle = []
 
#Guardar cada celda en un elemento
for row in reader:
    detalle.append(row)
 
#Imprimir el contenido en pantalla
for row in detalle:
    print row
 
File.close()
