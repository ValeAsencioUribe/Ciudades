#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

from PySide import QtGui, QtCore
import controller
from formulario import Ui_Ventana

class Formu(QtGui.QDialog):
    #Main para agregar una ciudad	
    def __init__(self,parent=None, id_categoria=None, id_paises=None):
        QtGui.QDialog.__init__(self,parent)
        self.ui = Ui_Ventana()
        self.ui.setupUi(self)
        self.show()
        self.cargar_paises()
        self.set_listeners()


    #Cargamos los paises en el combobox y lo mostramos
    #en la ventana
    def cargar_paises(self):
        paises = controller.obtener_paises()
        self.ui.combo_paises.addItem("Todos", -1)
        #Autocompleta la busqueda de los paises que estan en la base de datos
        completer = QtGui.QCompleter(map(lambda c: c["nombrep"], paises), self) 
        completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        self.ui.combo_paises.setCompleter(completer)
	for pais in paises:
	    self.ui.combo_paises.addItem(pais["nombrep"], pais["id_pais"])
    
    #Funcion para agregar una ciudad
    def agregar_ciudad(self):
        #sacamos el id del pais del combo box
	id_pais = self.ui.combo_paises.itemData(self.ui.combo_paises.currentIndex())
        #guardamos lo que sacamos de los search box en las variables
	nombre = self.ui.search_box.text()
        poblacion = self.ui.search_box1.text() 
        fundacion = self.ui.search_box2.text()
        superficie = self.ui.search_box3.text()
        densidad = self.ui.search_box4.text()
        gentilicio = self.ui.search_box5.text()
        #Si los campos nombres, poblacion y fundacion no estan rellenos
        #envia un mensaje diciendo que esos campos deben ser obligatorios
        if((nombre and poblacion and fundacion)==""):
            msgBox = QtGui.QMessageBox()
            msgBox.setText("Los campos con * deben ser obligatorios")
            msgBox.exec_()
        else:
            #Si estan los campos obligatorios entonces agregamos una ciudad
            #la agregamos llamando al metodo agregar que esta en el controller
	    nueva_celda = controller.agregar(nombre,poblacion,fundacion,superficie,densidad,gentilicio,id_pais)
	    self.reject() 
            #Se muestra un mensaje cuando se a agregado la celda
            msgBox = QtGui.QMessageBox()
            msgBox.setText("Ciudad agregada correctamente")
            msgBox.exec_()
    

    #Le damos funciones a los botones agregar y salir 
    def set_listeners(self):
        self.ui.button1.clicked.connect(self.agregar_ciudad)
        self.ui.button2.clicked.connect(self.cancel)
        
            
    def cancel(self):
	    self.reject()
