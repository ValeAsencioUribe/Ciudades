#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import controller
import ventana
import ventana1

from PySide import QtGui, QtCore
from ventanaprincipal import Ui_Ventana

class main(QtGui.QWidget):
    #funcion para definir los metodos que ocuparemos
    def __init__(self):
        super(main, self).__init__()
        self.ui = Ui_Ventana()
        self.ui.setupUi(self)
        self.cargar_categoria()
        self.show()
	self.set_signals()
	self.buscar_ciudad()
	
	
    #Busca las ciudades en la base de datos
    def buscar_ciudad(self):
        ciu = self.ui.search_box.text()
        ciudades = controller.buscar_ciudad(ciu)
        self.cargar_categoria(ciudades)
        

	
    #funcion para cargar la base de datos en la grilla
    def cargar_categoria(self, ciudades=None): 
        if ciudades is None:
            #obtenemos las ciudades
            ciudades = controller.get_ciudades()
            #funciona pero lo deje comentado porque solo me filtra las ciudades
            #completer = QtGui.QCompleter(map(lambda c: c["nombre"], ciudades), self) 
            #completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
            #self.ui.search_box.setCompleter(completer)
        #Creamos la grilla asociada a la base de datos
        self.model = QtGui.QStandardItemModel(len(ciudades),8)
        self.model.setHorizontalHeaderItem(0, QtGui.QStandardItem(u"Pais"))
        self.model.setHorizontalHeaderItem(1, QtGui.QStandardItem(u"id_ciudad"))
        self.model.setHorizontalHeaderItem(2, QtGui.QStandardItem(u"Nombre"))
        self.model.setHorizontalHeaderItem(3, QtGui.QStandardItem(u"Poblacion (hab)"))
        self.model.setHorizontalHeaderItem(4, QtGui.QStandardItem(u"Fundacion"))
        self.model.setHorizontalHeaderItem(5, QtGui.QStandardItem(u"Superficie (km²)"))
        self.model.setHorizontalHeaderItem(6, QtGui.QStandardItem(u"Densidad (hab/km²)"))
        self.model.setHorizontalHeaderItem(7, QtGui.QStandardItem(u"Gentilicio")) 
        #recorremos las ciudades y mostramos los atributos en la grilla
        r = 0
        for row in ciudades:
            index = self.model.index(r, 0, QtCore.QModelIndex()); 
            self.model.setData(index, row['nombrep'])
            index = self.model.index(r, 1, QtCore.QModelIndex()); 
            self.model.setData(index, row['id_ciudad'])
            index = self.model.index(r, 2, QtCore.QModelIndex()); 
            self.model.setData(index, row['nombre'])
            index = self.model.index(r, 3, QtCore.QModelIndex()); 
            self.model.setData(index, row['poblacion'])
            index = self.model.index(r, 4, QtCore.QModelIndex()); 
            self.model.setData(index, row['fundacion'])
            index = self.model.index(r, 5, QtCore.QModelIndex()); 
            self.model.setData(index, row['superficie'])
            index = self.model.index(r, 6, QtCore.QModelIndex()); 
            self.model.setData(index, row['densidad'])
            index = self.model.index(r, 7, QtCore.QModelIndex()); 
            self.model.setData(index, row['gentilicio'])
            r = r+1  
        #Le damos las dimensiones a las columnas de la grilla
        self.ui.table_categoria.setModel(self.model)
        self.ui.table_categoria.setColumnWidth(0,125)
        self.ui.table_categoria.hideColumn(1)
        self.ui.table_categoria.setColumnWidth(2,130)
        self.ui.table_categoria.setColumnWidth(3,120)
        self.ui.table_categoria.setColumnWidth(4,120)
        self.ui.table_categoria.setColumnWidth(5,120)
        self.ui.table_categoria.setColumnWidth(6,150)
        self.ui.table_categoria.setColumnWidth(7,150)
    
    
    #Le damos las acciones a los botones   
    def set_signals(self):
        self.ui.button4.clicked.connect(self.delete)
        self.ui.button2.clicked.connect(self.v_formulario)
        self.ui.button3.clicked.connect(self.editar)
        self.ui.button1.clicked.connect(self.buscar_ciudad)
    
    
    #Llamamos a la ventana para agregar ciudades    
    def v_formulario(self):
	formu = ventana.Formu(self)
	
	
    #Llamamos a la ventana para editar ciudades
    def e_formulario(self):
        formu = ventana1.Formu2(self)
    
    
    #Eliminamos una ciudad            
    def delete(self):
        model = self.ui.table_categoria.model()
        index = self.ui.table_categoria.currentIndex()
        #No se a seleccionado una fila
        if index.row() == 0: 
            #Mostramos un mensaje si no se a seleccionado una fila
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage("Debe seleccionar una fila")
            return False
        else:
	    codigo = model.index(index.row(), 1, QtCore.QModelIndex()).data()
	        #Si se a seleccionado una celda llamamos al metodo delete del controller
            if (controller.delete(codigo)):
		#volvemos a cargar la grilla
                self.cargar_categoria()
                #Mostramos un mensaje cuando hemos eliminado una celda
                msgBox = QtGui.QMessageBox()
                msgBox.setText("La ciudad fue eliminada.")
                msgBox.exec_()
                return True
            else:
		self.ui.errorMessageDialog = QtGui.QErrorMessage(self)
                self.ui.errorMessageDialog.showMessage("Error al eliminar el registro")
                return False
    
    
    #Metodo para editar una categoria            
    def editar(self):
        model = self.ui.table_categoria.model()
        index = self.ui.table_categoria.currentIndex()
        #Si no se a seleccionado una celda
        if index.row() == 0: 
            #Mostramos un mensaje si no se a seleccionado una fila
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage("Debe seleccionar una fila")
            return False
        else:
	    #Si se ha seleccionado una celda 
            codigo =str(model.index(index.row(), 1, QtCore.QModelIndex()).data())
            formu2 = ventana1.Formu2(self,codigo)
            formu2.exec_()	
            
            
def run():
    app = QtGui.QApplication(sys.argv)
    ma = main()
    sys.exit(app.exec_())


if __name__ == '__main__':
    run()
