# -*- coding: utf-8 -*-
import controller

from PySide import QtCore, QtGui

class Ui_Ventana(object):

    def setupUi(self, Window):
        Window.setObjectName("Window")
        Window.resize(1100, 600)
        #Creamos las dimensiones de la grilla
        self.table_categoria= QtGui.QTableView(Window)
        self.table_categoria.setGeometry(QtCore.QRect(60,90,960,500))
        self.table_categoria.setObjectName("table_producto")
        self.table_categoria.setSelectionBehavior(QtGui.QAbstractItemView.SelectRows)
        self.table_categoria.setAlternatingRowColors(True)
        self.table_categoria.setSortingEnabled(True)
        #caja de texto para buscar ciudades
        self.search_box = QtGui.QLineEdit(Window)
        self.search_box.setGeometry(QtCore.QRect(70, 50, 400, 25))
        #boton para buscar ciudades
        self.search_box.setObjectName("search_box")
        self.button1= QtGui.QPushButton(Window)
        self.button1.setGeometry(QtCore.QRect(490,49,100,25))
        self.button1.setObjectName("button1")
        #boton para agregar ciudades
        self.button2= QtGui.QPushButton(Window)
        self.button2.setGeometry(QtCore.QRect(680,50,100,25))
        self.button2.setObjectName("button2")
        #boton para editar ciudades
        self.button3= QtGui.QPushButton(Window)
        self.button3.setGeometry(QtCore.QRect(780,50,100,25))
        self.button3.setObjectName("button3")
        #boton para eliminar ciudades
        self.button4= QtGui.QPushButton(Window)
        self.button4.setGeometry(QtCore.QRect(880,50,100,25))
        self.button4.setObjectName("button4")
        self.retranslateUi(Window)
        QtCore.QMetaObject.connectSlotsByName(Window)
        
        
    def retranslateUi(self, Window):
        Window.setWindowTitle(QtGui.QApplication.translate("Window", "Ventana", None, QtGui.QApplication.UnicodeUTF8))
        #Mostramos el search box y los botones en la ventana
        self.search_box.setPlaceholderText(QtGui.QApplication.translate("Window", "Buscar por ciudad, poblacion, fundacion, superficie, etc", None, QtGui.QApplication.UnicodeUTF8))
        self.button1.setText(QtGui.QApplication.translate("Window", "Buscar", None, QtGui.QApplication.UnicodeUTF8))
        self.button2.setText(QtGui.QApplication.translate("Window", "Agregar", None, QtGui.QApplication.UnicodeUTF8))
        self.button3.setText(QtGui.QApplication.translate("Window", "Editar", None, QtGui.QApplication.UnicodeUTF8))
        self.button4.setText(QtGui.QApplication.translate("Window", "Eliminar", None, QtGui.QApplication.UnicodeUTF8))
