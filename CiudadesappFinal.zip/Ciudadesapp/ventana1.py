#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

from PySide import QtGui, QtCore
import controller
from formulario2 import Ui_Ventana

class Formu2(QtGui.QDialog):
	
    def __init__(self,parent=None, nombre=None ):
        QtGui.QDialog.__init__(self,parent)
        self.ui = Ui_Ventana()
        self.ui.setupUi(self)
        self.show()
        self.cargar_paises()
        self.nombre = nombre 
        #sacamos la informacion de las ciudades con info_ciudades 
        datos = controller.info_ciudades(nombre)
        #Recorremos la informacion y lo mostramos en las search_box para
        #ver cual queremos editar
        for dato in datos:
            #pasamos los campos con numeros a string
	    b=str(datos[1])
	    self.ui.search_box.setText(b)
	    poblacion = str(datos[2])
            self.ui.search_box1.setText(poblacion)
            fundacion = str(datos[3])
            self.ui.search_box2.setText(fundacion)
            superficie = str(datos[4])
	    self.ui.search_box3.setText(superficie)
	    densidad = str(datos[5])
	    self.ui.search_box4.setText(densidad)
	    gentilicio = str(datos[6])
	    self.ui.search_box5.setText(gentilicio)
	    #self.ui.combo_paises.setText(datos[7])
        self.ui.button1.clicked.connect(self.editar_dato)
        self.ui.button2.clicked.connect(self.cancel)
    

    #Cargamos los paises en un combo box y lo mostramos en la ventana     
    def cargar_paises(self):
        paises = controller.obtener_paises()
        self.ui.combo_paises.addItem("Todos", -1)
        #completer = QtGui.QCompleter(map(lambda c: c["nombrep"], paises), self) 
        #completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        #self.ui.combo_paises.setCompleter(completer)
	for pais in paises:
	    self.ui.combo_paises.addItem(pais["nombrep"], pais["id_pais"])
	      

    #Metodo para editar una ciudad
    def editar_dato(self, id_ciudad=None):
        #obtenemos el id de la ciudad con el metodo id_ciudad
        id_ciudad = controller.id_ciudad(self.nombre)
        #guardamos lo que sacamos de los search box en las variables
        antiguo = self.nombre
        nombre = self.ui.search_box.text()
        poblacion = self.ui.search_box1.text()
	fundacion = self.ui.search_box2.text()
	superficie = self.ui.search_box3.text()
	densidad = self.ui.search_box4.text()
	gentilicio = self.ui.search_box5.text()
        id_pais = self.ui.combo_paises.itemData(self.ui.combo_paises.currentIndex())
        actualizar = controller.actualizar(id_ciudad,nombre, poblacion, 
                     fundacion, superficie, densidad, gentilicio, id_pais)
	if actualizar:
	    self.reject()
	    self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage("El registro a sido actualizado")
        else:
            self.errorMessageDialog = QtGui.QErrorMessage(self)
            self.errorMessageDialog.showMessage("No se a podido actualizar")
     
           
    def cancel(self):
        self.reject()
		
		
		


	
	
	    
    
