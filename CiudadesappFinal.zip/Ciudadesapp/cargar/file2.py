# -*- coding: utf-8 -*-

import os
import csv
import sqlite3
 
FileName = "/home/vale/Escritorio/paises.cvs"
File = open(FileName, "rb")
reader = csv.reader(File)
 
conn = sqlite3.connect('BDcuidades.db')
c = conn.cursor()
#Arreglo para almacenar las ciudades
detalle = []
#Guardar cada celda en un elemento
for row in reader:
    detalle.append(row)
 
#Imprimir el contenido en pantalla 
for row in detalle:
    c.execute("INSERT INTO paises values(?,?)"(row[0], row[1]))
    #print "id_pais %s | nombre %s "(row[0], row[1])
 
conn.commit()
 
File.close()
c.close()
