#!/usr/bin/python
# -*- coding: utf-8 -*-

import sqlite3

#conectamos la base de datos
def connect():
    con = sqlite3.connect('base12.db')
    con.row_factory = sqlite3.Row
    return con
 

#Seleccionamos los elementos de la tabla ciudades 
def get_ciudades():
    con = connect()
    c = con.cursor()
    query = """SELECT p.nombrep,c.id_ciudad, c.nombre, c.poblacion, c.fundacion,
               c.superficie, c.densidad, c.gentilicio FROM ciudades c, paises p 
               WHERE c.fk_id_pais = p.id_pais ORDER BY c.densidad DESC"""
    result = c.execute(query)
    ciudades = result.fetchall()
    con.close()
    return ciudades


#Obtenemos los paises de la tabla paises
def get_paises():
    con = connect()
    c = con.cursor()
    query = """SELECT paises.nombrep FROM paises, ciudades 
               WHERE ciudades.fk_id_pais = paises.id_pais"""
    result = c.execute(query)
    paises = result.fetchall()
    con.close()
    return paises


#seleccionamos los paises para el combobox
def obtener_paises(): 
    con = connect()
    c = con.cursor()
    query = "SELECT id_pais, nombrep FROM paises"
    result= c.execute(query)
    paises = result.fetchall()
    con.close()
    return paises


#Funcion para eliminar una ciudad y sus elementos
#Eliminamos todos los elementos de la tabla ciudades
def delete(nombre):
    exito = False
    con = connect()
    c = con.cursor()
    query = "DELETE  FROM ciudades  WHERE id_ciudad = ?"
    try:
        resultado = c.execute(query, [nombre])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print "Error:", e.args[0]
    con.close()
    return exito


#Funcion para agregar una ciudad y sus elementos
#Insertamos todos los elementos de la tabla ciudades
def agregar(nombre,poblacion,fundacion,superficie,densidad,gentilicio,fk_id_pais):
    exito = False
    con = connect()
    c = con.cursor()
    query = """INSERT INTO ciudades (nombre,poblacion,fundacion,superficie,densidad, 
               gentilicio,fk_id_pais) VALUES (?, ?, ?, ?, ?, ?, ?)"""
    try:
        result = c.execute(query,[nombre,poblacion,fundacion,superficie,densidad,gentilicio,fk_id_pais])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = True
        print "Error:", e.args[0]
    con.close()
    return exito 


#Funcion para buscar por los elementos de la tabla ciudades
#seleccionamos todos los elementos para poder buscarlos
def buscar_ciudad(ciudad):
    con = connect()
    c = con.cursor()
    query = """SELECT p.nombrep, c.id_ciudad, c.nombre, c.poblacion, c.fundacion, c.superficie, c.densidad, c.gentilicio 
	       FROM ciudades c, paises p WHERE c.fk_id_pais = p.id_pais
            AND (p.nombrep LIKE '%'||?||'%' OR c.nombre LIKE '%'||?||'%' OR c.poblacion LIKE '%'||?||'%' OR 
            c.fundacion LIKE '%'||?||'%' OR c.superficie LIKE '%'||?||'%' OR c.densidad LIKE '%'||?||'%' OR 
            c.gentilicio LIKE '%'||?||'%' )"""
    result = c.execute(query, [ciudad, ciudad, ciudad, ciudad, ciudad, ciudad, ciudad ])
    ciudades = result.fetchall()
    con.close()
    return ciudades


#seleccionamos todos los elementos de la tabla ciudades    
def info_ciudades(nombre):
    con = connect()
    c = con.cursor()
    query = "SELECT * FROM ciudades WHERE id_ciudad = ?"
    resultado= c.execute(query, [nombre])
    ciudades = resultado.fetchone()
    con.close()
    return ciudades 
    

#
def obtener_ciudad():
    con = connect()
    c = con.cursor()
    query = "SELECT nombre FROM ciudades GROUP BY nombre"
    resultado= c.execute(query)
    nombre = resultado.fetchall()
    con.close()
    return nombre


#obtenemos el id de la ciudad por el nombre    
def id_ciudad(nombre):
	con = connect()
	c = con.cursor()
	query= "SELECT id_ciudad FROM ciudades WHERE nombre = ?"
	resultado = c.execute(query, [nombre])
	id_ciudad = resultado.fetchone()
	result = nombre[1]
	con.close
	return result


#funcion para actualizar una ciudad
def actualizar(id_ciudad,nombre, poblacion, fundacion, superficie, densidad, gentilicio,id_pais):
    exito = False
    con = connect()
    c = con.cursor()
    query ="""UPDATE ciudades SET nombre=?, poblacion=?, fundacion=?, superficie=?, densidad=?, gentilicio=?,
           fk_id_pais=? WHERE  id_ciudad=?"""
    try:
	result = c.execute(query,[id_ciudad,nombre, poblacion, fundacion, superficie, densidad, gentilicio,id_pais])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print "Error:", e.args[0]
    con.close()
    return exito 

