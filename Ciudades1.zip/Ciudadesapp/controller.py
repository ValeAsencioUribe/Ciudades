#!/usr/bin/python
# -*- coding: utf-8 -*-

import sqlite3

def connect():
    con = sqlite3.connect('base12.db')
    con.row_factory = sqlite3.Row
    return con
    
def get_ciudades():
    con = connect()
    c = con.cursor()
    query = """SELECT p.nombrep,c.nombre, c.poblacion, c.fundacion, c.superficie, c.densidad, c.gentilicio FROM ciudades c, paises p WHERE c.fk_id_pais = p.id_pais"""
    result = c.execute(query)
    ciudades = result.fetchall()
    con.close()
    return ciudades

def get_paises():
    con = connect()
    c = con.cursor()
    query = """SELECT paises.nombrep FROM paises, ciudades WHERE ciudades.fk_id_pais = paises.id_pais"""
    result = c.execute(query)
    paises = result.fetchall()
    con.close()
    return paises

def obtener_paises(): #paises para el combobox
    con = connect()
    c = con.cursor()
    query = "SELECT id_pais, nombrep FROM paises"
    result= c.execute(query)
    paises = result.fetchall()
    con.close()
    return paises

def delete(nombre):
    exito = False
    con = connect()
    c = con.cursor()
    query = "DELETE  FROM ciudades  WHERE ciudades.nombre = ?"
    try:
        resultado = c.execute(query, [nombre])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = False
        print "Error:", e.args[0]
    con.close()
    return exito

def agregar(nombre,poblacion,fundacion,superficie,densidad,gentilicio,fk_id_pais):
    exito = False
    con = connect()
    c = con.cursor()
    query = "INSERT INTO ciudades (nombre,poblacion,fundacion,superficie,densidad,gentilicio,fk_id_pais) VALUES (?, ?, ?, ?, ?, ?, ?)"
    try:
        result = c.execute(query,[nombre,poblacion,fundacion,superficie,densidad,gentilicio,fk_id_pais])
        con.commit()
        exito = True
    except sqlite3.Error as e:
        exito = True
        print "Error:", e.args[0]
    con.close()
    return exito 

def buscar_ciudad(ciudad):
    con = connect()
    c = con.cursor()
    query = """SELECT p.nombrep, c.nombre, c.poblacion, c.fundacion, c.superficie, c.densidad, c.gentilicio 
	       FROM ciudades c, paises p WHERE c.fk_id_pais = p.id_pais
            AND (p.nombrep LIKE '%'||?||'%' OR c.nombre LIKE '%'||?||'%' OR c.poblacion LIKE '%'||?||'%' OR c.fundacion LIKE '%'||?||'%' OR c.superficie LIKE '%'||?||'%' OR c.densidad LIKE '%'||?||'%' OR c.gentilicio LIKE '%'||?||'%' )"""

    result = c.execute(query, [ciudad, ciudad, ciudad, ciudad, ciudad, ciudad, ciudad ])
    ciudades = result.fetchall()
    con.close()
    return ciudades
    
def info_ciudades(nombre): #informacion ciudades
    con = connect()
    c = con.cursor()
    query = "SELECT * FROM ciudades WHERE nombre = ?"
    resultado= c.execute(query, [nombre])
    ciudad = resultado.fetchone()
    con.close()
    return ciudad 
 
