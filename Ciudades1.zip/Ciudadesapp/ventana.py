#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys

from PySide import QtGui, QtCore
import controller
from formulario import Ui_Ventana

class Formu(QtGui.QDialog):
	
    def __init__(self,parent=None, id_categoria=None, id_paises=None):
        QtGui.QDialog.__init__(self,parent)
        self.ui = Ui_Ventana()
        self.ui.setupUi(self)
        self.show()
        self.cargar_paises()
        self.set_listeners()

    def cargar_paises(self):
        paises = controller.obtener_paises()
        self.ui.combo_paises.addItem("Todos", -1)
        completer = QtGui.QCompleter(map(lambda c: c["nombrep"], paises), self) 
        completer.setCaseSensitivity(QtCore.Qt.CaseInsensitive)
        self.ui.combo_paises.setCompleter(completer)
	for pais in paises:
	    self.ui.combo_paises.addItem(pais["nombrep"], pais["id_pais"])
	
    def agregar_ciudad(self):
	id_pais = self.ui.combo_paises.itemData(self.ui.combo_paises.currentIndex())
	nombre = self.ui.search_box.text()
        poblacion = self.ui.search_box1.text() 
        fundacion = self.ui.search_box2.text()
        superficie = self.ui.search_box3.text()
        densidad = self.ui.search_box4.text()
        gentilicio = self.ui.search_box5.text()
        if((nombre and poblacion and fundacion)==""):
            msgBox = QtGui.QMessageBox()
            msgBox.setText("Los campos con * deben ser obligatorios")
            msgBox.exec_()
        else:
	    nueva_celda = controller.agregar(nombre,poblacion,fundacion,superficie,densidad,gentilicio,id_pais)
            msgBox = QtGui.QMessageBox()
            msgBox.setText("Ciudad agregada correctamente")
            msgBox.exec_()
     
    def set_listeners(self):
        self.ui.button1.clicked.connect(self.agregar_ciudad)
        self.ui.button2.clicked.connect(self.cancel)
        
            
    def cancel(self):
	    self.reject()
